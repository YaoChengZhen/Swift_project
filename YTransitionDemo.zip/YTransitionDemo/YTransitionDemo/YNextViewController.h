//
//  YNextViewController.h
//  YTransitionDemo
//
//  Created by BruceYao on 16/6/28.
//  Copyright © 2016年 BruceYao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YNextViewController : UIViewController<UINavigationControllerDelegate>

@end
